﻿//using System.ComponentModel.DataAnnotations;

//namespace SmartHospital.Models
//{
//    public class StockMedicine
//    {
//        public int  Id {get;set;}

//        [Required]
//        public int Quantity { get; set; }

       // price


//    }
//}
