﻿namespace SmartHospital.Models.Blood
{
    public class Donner
    {
        public int DonnerId { get; set; }

        public string Name { get; set; }

        public DateTime Donation_Date { get; set; }

        public int age { get; set; }

        public string gender { get; set; }

        public string Blood_Group { get; set; }

    }
}
