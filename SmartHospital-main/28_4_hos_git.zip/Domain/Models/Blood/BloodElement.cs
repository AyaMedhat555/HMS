﻿namespace SmartHospital.Models.Blood
{
    public class BloodElement
    {
        public int BloodElementId { get; set; }
        public string Blood_Group { get; set; }
        public float cost { get; set; }
        public int Quantity { get; set; }
    }
}
