﻿namespace SmartHospital.Models.Blood
{
    public class BloodBank
    {
        public int BloodBankId { get; set; }

       // public virtual ICollection<Donner> Donners { get; set; } = new HashSet<Donner>();

       // public virtual ICollection<BloodElement>Bloods { get; set; } = new HashSet<BloodElement>();

    }
}
