﻿namespace Domain.Models
{
    public class Nurse : User
    {
        public string nurseDegree { get; set; }
        public string NurseSpecialization { get; set; }
    }
}
