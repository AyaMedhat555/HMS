﻿namespace Domain.Models
{
    public class Receptionist:User
    {
    }
}
