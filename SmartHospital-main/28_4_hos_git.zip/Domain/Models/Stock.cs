﻿//using System.ComponentModel.DataAnnotations;

//namespace SmartHospital.Models
//{
//    public class Stock
//    {
//        public int StockId { get; set; }

//        public virtual ICollection<Medicine> Medicines { get; set; } = new HashSet<Medicine>();


//    }
//}
