﻿namespace Domain.Models
{
    public class Room
    {
        public int Id { get; set; }
        public int BedNumber { get; set; }
        public int RoomCharges { get; set; }
        
    }
}

