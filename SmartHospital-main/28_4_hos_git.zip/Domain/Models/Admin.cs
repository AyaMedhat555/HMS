﻿namespace Domain.Models
{
    public class Admin:User
    {
    }
}
