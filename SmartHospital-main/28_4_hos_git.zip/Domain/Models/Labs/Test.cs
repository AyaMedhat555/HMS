﻿namespace SmartHospital.Models.Labs
{
    public class Test
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float TestCharge { get; set; }
    }
}
