﻿namespace SmartHospital.Models.Labs
{
    public class TestDetailsCategorical:TestDetails
    {
      //  public TestParameterCategorical TestParameterCategorical { get; set; }
        public string MeasuredValue { get; set; }
    }
}
