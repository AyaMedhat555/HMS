﻿namespace SmartHospital.Models.Labs
{
    public class TestDetailsNumerical:TestDetails
    {
    // public  TestParameterNumerical TestParameterNumerical { get; set; }
        public float MeasuredValue { get; set; }
    }
}
