﻿namespace SmartHospital.Models.Labs
{
    public class TestParameterCategorical: TestParameter
    {
        public string Normalvalue { get; set; }
    }
}
