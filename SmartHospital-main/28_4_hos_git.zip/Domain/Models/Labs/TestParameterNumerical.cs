﻿namespace SmartHospital.Models.Labs
{
    public class TestParameterNumerical:TestParameter
    {
        public float Min_Range { get; set; }
        public float Max_Range { get; set; }
    }
}
